import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ExternalLink, Smartphone, Server, Globe as GlobeIcon } from 'lucide-react';
import { ProjectModal } from './ProjectModal';

const projectTypeIcons: Record<string, React.ReactNode> = {
  'Mobile Application': <Smartphone className="w-5 h-5" />,
  'تطبيق جوال': <Smartphone className="w-5 h-5" />,
  'Infrastructure': <Server className="w-5 h-5" />,
  'البنية التحتية': <Server className="w-5 h-5" />,
  'Web Application': <GlobeIcon className="w-5 h-5" />,
  'تطبيق ويب': <GlobeIcon className="w-5 h-5" />,
};

interface ProjectData {
  name: string;
  description: string;
  tech: string[];
  type: string;
  detailedDescription?: string;
  features?: string[];
  architecture?: string;
  demoUrl?: string;
  githubUrl?: string;
  image?: string;
  year?: string;
}

export const Projects: React.FC = () => {
  const { t, language } = useLanguage();
  const [selectedProject, setSelectedProject] = useState<ProjectData | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Helper functions for enhanced project data
  const getDetailedDescription = (index: number): string => {
    const descriptions = [
      language === 'en' 
        ? 'A comprehensive mobile security application built with Flutter following clean architecture principles. Features include real-time monitoring, secure authentication with JWT/OAuth 2.0, responsive UI design, and seamless integration with backend RESTful APIs. The app demonstrates advanced state management and offline-first capabilities.'
        : 'تطبيق أمني شامل للهاتف المحمول مبني بـ Flutter باتباع مبادئ البرمجة النظيفة. يتضمن المراقبة في الوقت الفعلي، والمصادقة الآمنة مع JWT/OAuth 2.0، وتصميم واجهة مستخدم متجاوب، والتكامل السلس مع واجهات برمجة التطبيقات الخلفية RESTful.',
      language === 'en'
        ? 'An enterprise-grade high availability database cluster implementation using Patroni, etcd, and HAProxy. Provides automatic failover, load balancing, and 99.99% uptime. Deployed on Kubernetes with Docker containerization, featuring automated backups, monitoring, and disaster recovery procedures.'
        : 'تنفيذ مجموعة قواعد بيانات عالية التوفر على مستوى المؤسسة باستخدام Patroni و etcd و HAProxy. يوفر الفشل التلقائي وموازنة التحميل ونسبة توفر 99.99٪. تم نشره على Kubernetes مع حاويات Docker.',
      language === 'en'
        ? 'Full-stack enterprise applications featuring robust backend services built with Django, Laravel, and PHP. Integrates seamlessly with modern frontends and cloud databases including PostgreSQL, Supabase, and MongoDB. Implements RESTful API architecture, authentication systems, and scalable microservices patterns.'
        : 'تطبيقات مؤسسية متكاملة تتميز بخدمات خلفية قوية مبنية باستخدام Django و Laravel و PHP. تتكامل بسلاسة مع الواجهات الأمامية الحديثة وقواعد البيانات السحابية.'
    ];
    return descriptions[index] || descriptions[0];
  };

  const getProjectFeatures = (index: number): string[] => {
    const features = [
      [
        language === 'en' ? 'Clean Architecture implementation with SOLID principles' : 'تطبيق البرمجة النظيفة مع مبادئ SOLID',
        language === 'en' ? 'Secure JWT/OAuth 2.0 authentication system' : 'نظام مصادقة آمن JWT/OAuth 2.0',
        language === 'en' ? 'Real-time data synchronization' : 'مزامنة البيانات في الوقت الفعلي',
        language === 'en' ? 'Offline-first architecture with local caching' : 'بنية تعمل دون اتصال مع التخزين المؤقت المحلي',
        language === 'en' ? 'Responsive UI for all screen sizes' : 'واجهة مستخدم متجاوبة لجميع أحجام الشاشات',
        language === 'en' ? 'Comprehensive error handling and logging' : 'معالجة شاملة للأخطاء والتسجيل'
      ],
      [
        language === 'en' ? 'Automatic failover and recovery' : 'الفشل التلقائي والاسترداد',
        language === 'en' ? 'Load balancing with HAProxy' : 'موازنة التحميل مع HAProxy',
        language === 'en' ? 'Kubernetes orchestration' : 'تنسيق Kubernetes',
        language === 'en' ? 'Docker containerization' : 'حاويات Docker',
        language === 'en' ? 'Automated backup and restore' : 'النسخ الاحتياطي والاستعادة التلقائية',
        language === 'en' ? 'Real-time monitoring and alerts' : 'المراقبة والتنبيهات في الوقت الفعلي'
      ],
      [
        language === 'en' ? 'RESTful API architecture' : 'بنية RESTful API',
        language === 'en' ? 'Microservices design pattern' : 'نمط تصميم الخدمات المصغرة',
        language === 'en' ? 'Database abstraction layer' : 'طبقة تجريد قاعدة البيانات',
        language === 'en' ? 'Cloud-native deployment' : 'النشر الأصلي السحابي',
        language === 'en' ? 'Scalable infrastructure' : 'البنية التحتية القابلة للتوسع',
        language === 'en' ? 'Comprehensive API documentation' : 'توثيق شامل لواجهة برمجة التطبيقات'
      ]
    ];
    return features[index] || features[0];
  };

  const getProjectArchitecture = (index: number): string => {
    const architectures = [
      language === 'en' ? 'Clean Architecture with BLoC Pattern' : 'البرمجة النظيفة مع نمط BLoC',
      language === 'en' ? 'High Availability Cluster Architecture' : 'بنية المجموعة عالية التوفر',
      language === 'en' ? 'Microservices with API Gateway' : 'الخدمات المصغرة مع بوابة API'
    ];
    return architectures[index] || architectures[0];
  };

  // Enhanced project data with detailed information
  const enhancedProjects: ProjectData[] = t.projects.items.map((project, index) => ({
    ...project,
    detailedDescription: getDetailedDescription(index),
    features: getProjectFeatures(index),
    architecture: getProjectArchitecture(index),
    demoUrl: '#demo',
    githubUrl: '#github',
    image: `/assets/images/projects/project-${index + 1}.jpg`, // يمكن استبدالها بصور حقيقية
    year: '2024',
  }));

  const openModal = (project: ProjectData) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedProject(null), 300); // Wait for animation
  };

  return (
    <section id="projects" className="py-12 sm:py-16 md:py-20 lg:py-32 bg-gradient-to-br from-slate-50 via-blue-50 to-cyan-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-800 overflow-hidden">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-8 sm:space-y-12">
          {/* Section Header */}
          <div className="text-center">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-3 sm:mb-4 px-4">
              {t.projects.title}
            </h2>
            <p className="text-sm sm:text-base lg:text-lg text-gray-600 dark:text-gray-400 mb-4 sm:mb-6 px-4">
              {t.projects.subtitle}
            </p>
            <div className="w-16 sm:w-20 h-1 bg-gradient-to-r from-blue-600 to-cyan-500 dark:from-cyan-400 dark:to-blue-400 mx-auto rounded-full"></div>
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {enhancedProjects.map((project, index) => (
              <div
                key={index}
                className="group bg-white dark:bg-slate-800 rounded-xl sm:rounded-2xl overflow-hidden border border-gray-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-cyan-500 transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1 flex flex-col cursor-pointer"
                onClick={() => openModal(project)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    openModal(project);
                  }
                }}
              >
                {/* Project Image Header */}
                <div className="relative aspect-video overflow-hidden bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-slate-700 dark:to-slate-600">
                  {/* Project Image */}
                  {project.image ? (
                    <img
                      src={project.image}
                      alt={project.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500/10 to-cyan-500/10 dark:from-blue-900/20 dark:to-cyan-900/20">
                      <div className="text-center p-4">
                        {projectTypeIcons[project.type] || <GlobeIcon className="w-16 h-16 sm:w-20 sm:h-20 mx-auto text-blue-500 dark:text-cyan-400 mb-2 opacity-40" />}
                      </div>
                    </div>
                  )}
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300"></div>
                  
                  {/* Type Badge - Floating */}
                  <div className="absolute top-3 end-3 z-10">
                    <span className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md text-blue-700 dark:text-cyan-400 rounded-full text-[10px] sm:text-xs font-bold shadow-lg border border-white/20">
                      {projectTypeIcons[project.type] ? (
                        <span className="w-3 h-3 sm:w-3.5 sm:h-3.5">
                          {projectTypeIcons[project.type]}
                        </span>
                      ) : null}
                      <span className="whitespace-nowrap">{project.type}</span>
                    </span>
                  </div>

                  {/* Project Name - Overlay at Bottom */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5 z-10">
                    <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-white leading-tight drop-shadow-lg">
                      {project.name}
                    </h3>
                  </div>
                </div>

                {/* Project Content */}
                <div className="p-4 sm:p-5 lg:p-6 flex-1 flex flex-col">
                  <p className="text-gray-600 dark:text-gray-400 text-xs sm:text-sm leading-relaxed mb-4 sm:mb-6 flex-1">
                    {project.description}
                  </p>

                  {/* Tech Stack */}
                  <div className="mb-4 sm:mb-6">
                    <h4 className="text-[10px] sm:text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2 sm:mb-3">
                      Tech Stack
                    </h4>
                    <div className="flex flex-wrap gap-1.5 sm:gap-2">
                      {project.tech.map((tech, idx) => (
                        <span
                          key={idx}
                          className="px-2 sm:px-3 py-0.5 sm:py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-md sm:rounded-lg text-[10px] sm:text-xs font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 sm:gap-3">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        openModal(project);
                      }}
                      className="flex-1 flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2.5 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 dark:from-cyan-500 dark:to-blue-500 dark:hover:from-cyan-600 dark:hover:to-blue-600 text-white rounded-lg text-xs sm:text-sm font-medium transition-all duration-300 transform hover:scale-105"
                    >
                      <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
                      <span>{language === 'en' ? 'View Details' : 'عرض التفاصيل'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Project Details Modal */}
      <ProjectModal
        isOpen={isModalOpen}
        onClose={closeModal}
        project={selectedProject}
      />
    </section>
  );
};
